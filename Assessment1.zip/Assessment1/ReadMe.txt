A project designed to fit the requirements of Game Programmings first assignment.
Each weapon has seperate values for damage and what they are effective on.
The stabbing weapon deals the most damage to unarmored opponents, the blunt weapon deals the most to armor, and the slash weapon is a balance between the two.
Any fight can be won with any weapon except for the boss.
5 Sand throws against any normal combatant will instantly kill them (except boss).
The boss must be killed by throwing sand first and then using a blunt weapon to not rely on rng for him missing (There is a chance you will miss and die though with any weapon).
After beating the boss you will start NG+ which has differebt descriptions, a different ending, and also your fists deal 1000 damage base.
After dying, or completing the game on NG+, the player will exit the game by pressing enter.