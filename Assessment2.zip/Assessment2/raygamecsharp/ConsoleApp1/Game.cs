﻿using System;
using System.Diagnostics;
using System.Collections.Generic;
using System.Text;
using Raylib;
using static Raylib.Raylib;

namespace ConsoleApp1
{
    /// <summary>
    /// This is the main class that allows for things in the game such as objects, text object, and sprites to be represented in the actual game.
    /// </summary>
    class Game
    {
        // All of the variables and classes needed to make the game work.

        Stopwatch stopwatch = new Stopwatch();

        private long currentTime = 0;
        private long lastTime = 0;
        private float timer = 0;
        private float timeRemaining = 30;
        private int fps = 1;
        private int frames;
        private int bulletNum = 0;
        private float speed = 1;
        private int targetRemaining = 20;
        public bool winState = false;
        public bool loseState = false;

        Random rd = new Random();
        SceneObject tankObject = new SceneObject();
        SceneObject turretObject = new SceneObject();
        SceneObject[] bulletObject = new SceneObject[20];
        SceneObject tankHitboxPoint1 = new SceneObject();
        SceneObject tankHitboxPoint2 = new SceneObject();
        SceneObject tankHitboxPoint3 = new SceneObject();
        SceneObject tankHitboxPoint4 = new SceneObject();
        SceneObject barrelTip = new SceneObject();
        SceneObject[] glueSpot = new SceneObject[3];
        SceneObject obstacleArea = new SceneObject();
        SceneObject[] targetObstacles = new SceneObject[20];

        SpriteObject tankSprite = new SpriteObject();
        SpriteObject turretSprite = new SpriteObject();
        SpriteObject[] bulletSprite = new SpriteObject[20];
        SpriteObject[] glueSprite = new SpriteObject[3];
        SpriteObject[] targetSprite = new SpriteObject[20];
        static Texture2D flowerTex = new Texture2D();

        Vector3 bulletDirection = new Vector3(0,0,0);

        private float deltaTime = 0.005f;

        // Initialization to assign variables with their correct values.

        public void Init()
        {
            stopwatch.Start();
            lastTime = stopwatch.ElapsedMilliseconds;

            // A few loops that assign my arrays with the values I need.

            for (int i = 0; i < 3; i++)
            {
                glueSprite[i] = new SpriteObject();
                glueSprite[i].Load("Glue.png");
                glueSprite[i].SetPosition(-glueSprite[i].Width / 2.0f, -glueSprite[i].Height / 2.0f);
                glueSpot[i] = new SceneObject();
                glueSpot[i].AddChild(glueSprite[i]);
                glueSpot[i].SetPosition(300 + (i * 200), rd.Next(200, 960));
            }
            
            
            for (int i = 0; i < 20; i++)
            {
                targetSprite[i] = new SpriteObject();
                targetSprite[i].Load("Target.png");
                targetSprite[i].SetPosition(-targetSprite[i].Width / 2.0f, -targetSprite[i].Height / 2.0f);
                targetObstacles[i] = new SceneObject();
                targetObstacles[i].AddChild(targetSprite[i]);
                obstacleArea.AddChild(targetObstacles[i]);
                targetObstacles[i].SetPosition(50 + (50 * i), rd.Next(50, 910));
                bulletSprite[i] = new SpriteObject();
                bulletSprite[i].Load("FriendBullet.png");
                bulletSprite[i].SetPosition(-bulletSprite[i].Width / 2.0f, -bulletSprite[i].Height / 2.0f);
                bulletObject[i] = new SceneObject();
                bulletObject[i].AddChild(bulletSprite[i]);
                bulletObject[i].IsActive = false;
            }
            flowerTex = LoadTexture("Flower.png");

            tankSprite.Load("tankBlue_outline.png");
            tankSprite.SetRotate(-90 * (float)(Math.PI / 180.0f));
            tankSprite.SetPosition(-tankSprite.Width / 2.0f, tankSprite.Height / 2.0f);

            barrelTip.SetPosition(60,0);
            tankHitboxPoint1.SetPosition(-tankSprite.Width / 2.0f, -tankSprite.Height / 2.0f - 4);
            tankHitboxPoint2.SetPosition(tankSprite.Width / 2.0f - 4, -tankSprite.Height / 2.0f - 4);
            tankHitboxPoint3.SetPosition(tankSprite.Width / 2.0f - 4, tankSprite.Height / 2.0f);
            tankHitboxPoint4.SetPosition(-tankSprite.Width / 2.0f, tankSprite.Height / 2.0f);

            turretSprite.Load("barrelBlue.png");
            turretSprite.SetRotate(-90 * (float)(Math.PI / 180.0f));
            turretSprite.SetPosition(0, turretSprite.Width / 2.0f);

            // Assigning children objects to their necessary parent objects as well as set the tank position.
            
            turretObject.AddChild(turretSprite);
            turretObject.AddChild(barrelTip);
            tankObject.AddChild(tankSprite);
            tankObject.AddChild(turretObject);;
            tankObject.AddChild(tankHitboxPoint1);
            tankObject.AddChild(tankHitboxPoint2);
            tankObject.AddChild(tankHitboxPoint3);
            tankObject.AddChild(tankHitboxPoint4);
            tankObject.SetPosition(GetScreenWidth() / 2.0f, GetScreenHeight() / 2.0f);
        }

        public void Shutdown()
        { }

        // Update function thats called once every frame.

        public void Update()
        {
            // Checks what frame rate the game is running at as well as keeping the current time.

            currentTime = stopwatch.ElapsedMilliseconds;
            deltaTime = (currentTime - lastTime)/1000.0f;

            timer += deltaTime;
            if (timer >= 1)
            {
                fps = frames;
                frames = 0;
                timer--;
            }
            frames++;

            timeRemaining -= deltaTime;

            // Checks the inputs of the player and gives the proper response accordingly.

            if (IsKeyDown(KeyboardKey.KEY_A))
            {
                tankObject.Rotate(-deltaTime * 10);
            }

            if (IsKeyDown(KeyboardKey.KEY_D))
            {
                tankObject.Rotate(deltaTime * 10);
            }

            if (!tankObject.box.Overlaps(glueSpot[0].box) && !tankObject.box.Overlaps(glueSpot[1].box) && !tankObject.box.Overlaps(glueSpot[2].box))
            {
                speed = 1;
            }

            else
            {
                speed = .25f;
            }

            if (IsKeyDown(KeyboardKey.KEY_W))
            {
                Vector3 facing = new Vector3(tankObject.LocalTransform.m1, tankObject.LocalTransform.m2, 1) * deltaTime * 500 * speed;
                tankObject.Translate(facing.x, facing.y);
            }

            if (IsKeyDown(KeyboardKey.KEY_S))
            {
                Vector3 facing = new Vector3(tankObject.LocalTransform.m1, tankObject.LocalTransform.m2, 1) * deltaTime * -500 * speed;
                tankObject.Translate(facing.x, facing.y);
            }
            
            if (IsKeyDown(KeyboardKey.KEY_Q))
            {
                turretObject.Rotate(-deltaTime * 5);
            }

            if (IsKeyDown(KeyboardKey.KEY_E))
            {
                turretObject.Rotate(deltaTime * 5);
            }

            // If the space key is hit then multiple bullets can be fired up to 20 at one time.

            if (IsKeyPressed(KeyboardKey.KEY_SPACE))
            {
                bulletObject[bulletNum].SetPosition(barrelTip.GlobalTransform.m7, barrelTip.GlobalTransform.m8);
                bulletDirection = new Vector3(barrelTip.GlobalTransform.m1, barrelTip.GlobalTransform.m2, 1) * (deltaTime==0?.001f:deltaTime) * 250;

                bulletObject[bulletNum].Fired(bulletDirection, bulletObject[bulletNum]);

                bulletObject[bulletNum].IsActive = true;
                bulletNum++;
                if (bulletNum > 19)
                {
                    bulletNum = 0;
                }
            }

            // Resets the position for the tank if they move too far right or too far left.

            if (tankObject.GlobalTransform.m7 > 1350)
            {
                tankObject.GlobalTransform.m7 = -20;
            }

            if (tankObject.GlobalTransform.m7 < -70)
            {
                tankObject.GlobalTransform.m7 = 1300;
            }

            if (tankObject.GlobalTransform.m8 > 1080)
            {
                tankObject.GlobalTransform.m8 = 0;
            }

            if (tankObject.GlobalTransform.m8 < 0)
            {
                tankObject.GlobalTransform.m8 = 1030;
            }

            // Keeps moving the object once fired.

            foreach (SceneObject bullet in bulletObject)
            {
                if(bullet.IsActive)
                bullet.Fired(bullet);
            }

            tankObject.Update(deltaTime);

            lastTime = currentTime;

            // Sets the win and lose states.

            if (targetRemaining == 0)
            {
                winState = true;
            }

            if (timeRemaining < 0)
            {
                loseState = true;
            }
        }

        // Assigns the hitbox for my arrays of objects.
        public void ArrayHitboxAssigner(SceneObject[] objects, SpriteObject[] sprites)
        {
            for (int i = 0; i < objects.Length; i++)
            {
                List<Vector3> hitboxAssignedPoints = new List<Vector3>()
                {
                    new Vector3 (-sprites[i].Width / 2.0f + objects[i].GlobalTransform.m7, -sprites[i].Height / 2.0f + objects[i].GlobalTransform.m8, 1),
                    new Vector3 (sprites[i].Width / 2.0f + objects[i].GlobalTransform.m7, -sprites[i].Height / 2.0f + objects[i].GlobalTransform.m8, 1),
                    new Vector3 (sprites[i].Width / 2.0f + objects[i].GlobalTransform.m7, sprites[i].Height / 2.0f + objects[i].GlobalTransform.m8, 1),
                    new Vector3 (-sprites[i].Width / 2.0f + objects[i].GlobalTransform.m7, sprites[i].Height / 2.0f + objects[i].GlobalTransform.m8, 1)
                };
                objects[i].boundingBox(hitboxAssignedPoints);
                objects[i].Draw();
            }
        }

        //  Assigns the hitbox to the individual objects I have.

        public void ObjectHitboxAssigner(SceneObject objects, SpriteObject sprites)
        {
            List<Vector3> hitboxAssignedPoints = new List<Vector3>()
            {
                new Vector3 (-sprites.Width / 2.0f + objects.GlobalTransform.m7, -sprites.Height / 2.0f + objects.GlobalTransform.m8, 1),
                new Vector3 (sprites.Width / 2.0f + objects.GlobalTransform.m7, -sprites.Height / 2.0f + objects.GlobalTransform.m8, 1),
                new Vector3 (sprites.Width / 2.0f + objects.GlobalTransform.m7, sprites.Height / 2.0f + objects.GlobalTransform.m8, 1),
                new Vector3 (-sprites.Width / 2.0f + objects.GlobalTransform.m7, sprites.Height / 2.0f + objects.GlobalTransform.m8, 1)
            };
            objects.boundingBox(hitboxAssignedPoints);
            objects.Draw();
        }

        // This method draws the actual objects for the points.

        public void Draw()
        {
            
            BeginDrawing();
            // Draws the objects if there is no win or lose

            if (!winState && !loseState)
            {
                ClearBackground(Color.DARKPURPLE);
                DrawText(fps.ToString(), 10, 10, 12, Color.WHITE);
                DrawText("Remaining Targets: " + targetRemaining.ToString(), 960, 10, 24, Color.WHITE);
                DrawText("Time Remaining: " + (int)timeRemaining, 420, 10, 24, Color.WHITE);

                tankObject.Draw();

                ObjectHitboxAssigner(tankObject, tankSprite);
                ArrayHitboxAssigner(glueSpot, glueSprite);
                ArrayHitboxAssigner(targetObstacles, targetSprite);
                ArrayHitboxAssigner(bulletObject, bulletSprite);

                for (int i = 0; i < 20; i++)
                {
                    for (int j = 0; j < 20; j++)
                    {
                        if (targetObstacles[j].box.Overlaps(bulletObject[i].box))
                        {
                            if (targetObstacles[j].IsHit == false)
                            {
                                targetSprite[j].Set(flowerTex);
                                targetObstacles[j].IsHit = true;
                                targetRemaining--;
                            }
                        }
                    }
                }
            }
            // Checks the winstates and gives the end game screens.

            if (winState)
            {
                ClearBackground(Color.DARKPURPLE);
                DrawText("YOU WIN THE GAME!", 400, 480, 64 ,Color.WHITE);
                timeRemaining = 30;
            }

            if (loseState)
            {
                ClearBackground(Color.DARKPURPLE);
                DrawText("YOU LOST YOU LOSER, \nI BET YOU LIVE IN LOSER TOWN AND LOST THE ELECTION \nTO BE THE MAYOR BECAUSE YOURE A LOSER!", 100, 480, 32, Color.WHITE);
                timeRemaining = -100;
            }
            EndDrawing();
        }
    }
}
